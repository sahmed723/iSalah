//
//  WidgetUtils.swift
//  iSalahWidgetExtension
//
//  Created by Tharindu Perera on 11/18/20.
//  Copyright © 2020 Intelcy. All rights reserved.
//

import Foundation

class WidgetUtils {
    
    static var currentParyerTimeShowTime: Int = 5  // In minutes
    
    static func getMonth(date: Date = Date()) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM"
        return formatter.string(from: date)
    }
    
    static func getMidNightDate() -> Date {
        let now = Date()
        let midnight = Calendar.current.startOfDay(for: now)
        return midnight
    }
    
    static func getTimelineForSnapshot(prayerTimes: [PrayerTime]) -> Date {
        let now = Date()
        let endOfCurrentDisplayTimeFromNow = Calendar.current.date(byAdding: .minute, value: 5, to: now)!
        
        if now < prayerTimes.first?.timeObject ?? Date() {
            return WidgetUtils.getMidNightDate()
        }
        
        for prayerTime in prayerTimes {
            if prayerTime.timeObject >= now && prayerTime.timeObject < endOfCurrentDisplayTimeFromNow {
                return prayerTime.timeObject
            }
        }
        var previousPrayerTime: Date?
        for prayerTime in prayerTimes {
            if prayerTime.timeObject > endOfCurrentDisplayTimeFromNow {
                let previousEndingTime = Calendar.current.date(byAdding: .minute, value: WidgetUtils.currentParyerTimeShowTime, to: previousPrayerTime ?? now)!
                return previousEndingTime
            }
            previousPrayerTime = prayerTime.timeObject
        }
        
        return now
    }
}

extension String {

    var length: Int {
        return count
    }

    subscript (i: Int) -> String {
        return self[i ..< i + 1]
    }

    func substring(fromIndex: Int) -> String {
        return self[min(fromIndex, length) ..< length]
    }

    func substring(toIndex: Int) -> String {
        return self[0 ..< max(0, toIndex)]
    }

    subscript (r: Range<Int>) -> String {
        let range = Range(uncheckedBounds: (lower: max(0, min(length, r.lowerBound)),
                                            upper: min(length, max(0, r.upperBound))))
        let start = index(startIndex, offsetBy: range.lowerBound)
        let end = index(start, offsetBy: range.upperBound - range.lowerBound)
        return String(self[start ..< end])
    }
}
